import java.util.ArrayList;

public class DisplayClass {
static ArrayList<VehicleClass> Trucks=Main.Trucks;
static ArrayList<VehicleClass> Ships=Main.Ships;
static ArrayList<VehicleClass> Airplanes=Main.Airplanes;

    public static void main(String[] Args)
    {

    }

}
