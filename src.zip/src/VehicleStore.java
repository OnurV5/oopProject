public abstract class VehicleStore {  // This class is for implementing the factory method
    public abstract Vehicle getVehicle(int speed, int fuelConsumptionper100KM, int range, int weightCapacity,int ID);
}
