public abstract class VehicleStore {  // This class is for implementing the factory method
    public abstract Vehicle getVehicle(int speed, int fuelConsumption, int range, int weightCapacity);
}
